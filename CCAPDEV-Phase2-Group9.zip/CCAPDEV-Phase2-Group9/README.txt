Github repo: https://github.com/VinceRyanWang/CCAPDEV-MCO2/tree/main

1. Unzip the folder, make sure the folder CCAPDEV-Phase2-Group9 has all the files inside.
(Make sure not to have the same folder name CCPADEV-Phase2-Group9 in another)

2. Open command prompt and change the directory of CCAPDEV-Phase2-Group9

3. Enter the ff in cmd: "node server.js"

4. The main pages of our MCO2 are "profile" and "reservationCatalog"
   Access this via your browser by typing "localhost:3000/profile" and "localhost:3000/reservationCatalog"

5. You may play around by just changing /(//change me to coressponding html file without .html)

Note: We used MongoDB Atlas, we are unsure how to share/give acces the database to you sir. We have relied on white listing IP addresses.