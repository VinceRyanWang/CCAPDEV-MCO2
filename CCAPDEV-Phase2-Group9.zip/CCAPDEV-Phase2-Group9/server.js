const mongoose = require('mongoose')

mongoose.connect('mongodb+srv://vincewang:vincewang@cluster0.0jmei8b.mongodb.net/account?retryWrites=true&w=majority&appName=Cluster0')
  .then(() => {
    console.log('Connected to MongoDB Atlas');
  })
  .catch((error) => {
    console.error('Error connecting to MongoDB Atlas:', error);
  });

const express = require('express');
const app = new express();
const fileUpload = require('express-fileupload');
const path = require('path');
const bodyParser = require('body-parser');
const exphbs = require('express-handlebars');
const Account = require('./models/Account');
const Reservation = require('./models/Reservation');
const Lab = require('./models/Lab');
const TimeSlot = require('./models/TimeSlot');
const Seat = require('./models/Seat');

//mongoose.set('strictQuery', false);

app.use(express.json()) 
app.use(express.urlencoded( {extended: true}));
app.use(express.static(__dirname))
app.use(fileUpload())

var hbs = require('hbs')
//app.engine('.hbs', exphbs.engine({ extname: '.hbs' }));
app.set('view engine','hbs');
app.set('views', path.join(__dirname, 'views'));
const Handlebars = require('handlebars');
const { TopologyDescriptionChangedEvent } = require('mongodb');

/*Handlebars.registerHelper('eq', function (a, b, options) {
  return a === b ? options.fn(this) : options.inverse(this);
});*/

app.get('/profile',  async (req, res) => {
    const profile = await Account.findOne({name: "Sana"});
    console.log(profile);
    res.render('profile', { profile });
});

app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname, 'index.html'));
});
//////////////////////////////////////////////
app.get('/reservationCatalog', async (req, res) => {
  const reservations = await Reservation.find()
    .populate('reservee')
    .populate('seat_id')
    .populate('timeSlot_id')
    .populate('lab_id');
  
  const combinedReservations = reservations.map(reservation => {
    return {
      name: reservation.reservee.name,
      profilePicture: reservation.reservee.profilePicture,
      seat: reservation.seat_id.seat,
      room: reservation.lab_id.room, 
      timeName: reservation.timeSlot_id.timeName,
      reservation_date: reservation.reservation_date,
    };
  });

  res.render('reservationCatalog', { combinedReservations });
});

app.get('/home_tech', function (req, res) {
  res.sendFile(path.join(__dirname, 'home_tech.html'));
});

app.get('/confirmation', function (req, res) {
  res.sendFile(path.join(__dirname, 'iconfirmation.html'));
});

app.get('/home', function (req, res) {
  res.sendFile(path.join(__dirname, 'home.html'));
});

app.get('/labSelection', function (req, res) {
  res.sendFile(path.join(__dirname, 'labSelection.html'));
});

app.get('/reserve', function (req, res) {
  res.sendFile(path.join(__dirname, 'reserve.html'));
});

app.get('/setVisibility', function (req, res) {
  res.sendFile(path.join(__dirname, 'setVisibility.html'));
});
//for population
/*
async function trying() {
  const profile = await Account.findOne({name: "Sana"});

  const labData = new Lab({ room: 'Lab A' });

  const timeSlotData = new TimeSlot({ timeName: '7:00-7:30' });

  const seatData = new Seat({ seat: 'A2', room_id: labData._id, status: 'Available' });

  const reservationData = new Reservation({ 
    reservee: profile._id,
    seat_id: seatData._id,
    timeSlot_id: timeSlotData._id,
    reservation_date: '2024-03-15',
    visibility: 'Visible'
  });
  
  /*await labData.save();
  
  await seatData.save();
  await reservationData.save();*/
  //await timeSlotData.save();
//}


///////////////////////////////////////////
var server = app.listen(3000, function () {
    console.log('Node server is running..');
});