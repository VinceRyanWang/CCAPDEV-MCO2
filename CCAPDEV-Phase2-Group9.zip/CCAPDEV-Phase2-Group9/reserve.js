document.addEventListener("DOMContentLoaded", function() {
   let seatsContainer = document.querySelector(".all-seats");
    for (var i = 0; i < 59; i++) {
      let randint = Math.floor(Math.random() * 2);
      let booked = randint === 1 ? "booked" : "";
      let seatHtml = '<input type="checkbox" name="box" id="s' + (i + 1) + '" />';
      seatHtml += '<label for="s' + (i + 1) + '" class="seat ' + booked + '"></label>';
      seatsContainer.insertAdjacentHTML("beforeend", seatHtml);
    }

    let bookedSeats = document.querySelectorAll(".seat.booked");
    bookedSeats.forEach((seat) => {
      let reservedText = document.createElement("span");
      reservedText.classList.add("reserved-text");
      reservedText.textContent = "Reserved";
      seat.appendChild(reservedText);
    });

    let box = seatsContainer.querySelectorAll("input");
    box.forEach((ticket) => {
      ticket.addEventListener("change", () => {
        let amount = document.querySelector(".amount").innerHTML;
        amount = Number(amount);

        if (ticket.checked) {
          amount += 1;
        } else {
          amount -= 1;
        }
        document.querySelector(".amount").innerHTML = amount;
      });
    });
});
