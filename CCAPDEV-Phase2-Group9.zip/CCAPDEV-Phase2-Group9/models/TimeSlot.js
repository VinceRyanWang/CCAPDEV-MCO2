const mongoose = require('mongoose')

const TimeSlot = new mongoose.Schema({
    timeName: String
}, { collection: 'timeSlots' });

module.exports = mongoose.model('TimeSlot', TimeSlot)