const mongoose = require('mongoose')

const Reservation = new mongoose.Schema({
    reservee: { type: mongoose.Schema.Types.ObjectId, ref: 'Account' },
    seat_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Seat' },
    timeSlot_id: { type: mongoose.Schema.Types.ObjectId, ref: 'TimeSlot' },
    lab_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Lab' },
    reservation_date: String,
    visibility: {type: String, enum: ['Anonymous', 'Visible'], default: 'Visible'}
});

module.exports = mongoose.model('Reservation', Reservation)