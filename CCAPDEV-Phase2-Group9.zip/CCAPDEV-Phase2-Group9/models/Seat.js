const mongoose = require('mongoose')

const Seat = new mongoose.Schema({
    seat: String,
    room_id:{ type: mongoose.Schema.Types.ObjectId, ref: 'Lab' },
    status: {type: String, enum: ['Available', 'Booked'], default: 'Available'}
    
});

module.exports = mongoose.model('Seat', Seat)