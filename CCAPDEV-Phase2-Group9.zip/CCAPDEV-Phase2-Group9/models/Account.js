const mongoose = require('mongoose')

const Account = new mongoose.Schema({
    name: String,
    email: String,
    password: String,
    profilePicture: String,
    accountType: { type: String, enum: ['student', 'technician'], default: 'student' },
});

module.exports = mongoose.model('Account', Account)